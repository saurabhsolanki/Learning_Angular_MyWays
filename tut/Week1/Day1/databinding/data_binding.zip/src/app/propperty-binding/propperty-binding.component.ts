import { Component } from '@angular/core';

@Component({
  selector: 'app-propperty-binding',
  templateUrl: './propperty-binding.component.html',
  styleUrls: ['./propperty-binding.component.css']
})
export class ProppertyBindingComponent {
age:number = 25;
b1:boolean = false;
b2:boolean = false;
}
